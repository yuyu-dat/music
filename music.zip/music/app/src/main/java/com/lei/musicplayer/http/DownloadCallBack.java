package com.lei.musicplayer.http;

/**
 * Created by lei on 2017/10/23.
 */
public interface DownloadCallBack {

    void onMusicSuccess();

    void onMusicFail();

}
