package com.lei.musicplayer.service;

/**
 * Created by lei on 2017/8/30.
 */
public interface ScanCallBack {

    void onFail(String msg);

    void onFinish();

}
