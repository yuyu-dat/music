package com.lei.musicplayer.service;

/**
 * Created by Lei on 2018/4/26.
 */

public interface IPlayerService {

    void onPlay();

    void stop();

    void onPlayNext();

    void onPlayPrev();

}
