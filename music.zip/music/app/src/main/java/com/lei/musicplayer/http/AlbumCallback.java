package com.lei.musicplayer.http;

/**
 * 下载音乐图片返回接口
 * Created by lei on 2018/1/21.
 */
public interface AlbumCallback {

    void onSuccess();

    void onFail();

}
