package com.lei.musicplayer.activity;

import android.content.Intent;

import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.FragmentTransaction;
import androidx.viewpager.widget.ViewPager;

import com.bumptech.glide.Glide;
import com.google.android.material.navigation.NavigationView;
import com.lei.musicplayer.constant.AppConstant;
import com.lei.musicplayer.R;
import com.lei.musicplayer.adapter.FragmentAdapter;
import com.lei.musicplayer.application.AppCache;
import com.lei.musicplayer.fragment.HomeFragment;
import com.lei.musicplayer.fragment.LocalFragment;
import com.lei.musicplayer.fragment.OnlineFragment;
import com.lei.musicplayer.fragment.PlayFragment;
import com.lei.musicplayer.service.PlayerService;
import com.lei.musicplayer.service.OnPlayMusicListener;
import com.lei.musicplayer.util.Util;


public class MainActivity extends BaseActivity
        implements NavigationView.OnNavigationItemSelectedListener , ViewPager.OnPageChangeListener,
        SeekBar.OnSeekBarChangeListener,View.OnClickListener,OnPlayMusicListener {

    private static final String TAG = MainActivity.class.getSimpleName();
    DrawerLayout drawer;
    NavigationView navigationView;
    private int play_progress = 0;
    private int seekBarProgress = 0;
    //view
    private LocalFragment localFragment;
    private OnlineFragment onlineFragment;
    private HomeFragment homeFragment;
    private PlayFragment playFragment;
    ImageButton img_next, img_play, img_category,img_search;
    ImageView img_bottom;
    TextView tvMusicName,tvMusicAuthor,tvMusicDuration;
    SeekBar mSeekBarCurrent;
    ViewPager viewPager;
    TextView tvLocal,tvOnline,tvHome;
    //private boolean haveLrc = false;


    @Override
    protected int getLayoutId() {
        return R.layout.activity_main;
    }

    @Override
    protected void initView() {
        getPlayService().setOnPlayerListener(this);

        drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        navigationView = (NavigationView) findViewById(R.id.nav_view);
        tvLocal = (TextView) findViewById(R.id.tv_local);
        tvOnline = (TextView) findViewById(R.id.tv_online);
        tvHome = (TextView)findViewById(R.id.tv_home);
        changeTitleColor(0);

        viewPager = (ViewPager) findViewById(R.id.main_view_pager);
        homeFragment = new HomeFragment();
        localFragment = new LocalFragment();
        onlineFragment = new OnlineFragment();
        FragmentAdapter fragmentAdapter = new FragmentAdapter(getSupportFragmentManager());
        fragmentAdapter.addFragment(homeFragment);
        fragmentAdapter.addFragment(localFragment);
        fragmentAdapter.addFragment(onlineFragment);
        viewPager.setAdapter(fragmentAdapter);
        viewPager.setCurrentItem(0);
        img_category = (ImageButton) findViewById(R.id.img_btn_category);
        img_category.setOnClickListener(this);
        img_search = (ImageButton) findViewById(R.id.img_btn_search);
        img_search.setOnClickListener(this);
        //bottom play
        img_play = (ImageButton) findViewById(R.id.img_play);
        img_next = (ImageButton) findViewById(R.id.img_next);
        img_bottom = (ImageView) findViewById(R.id.img_music_bottom);
        tvMusicName = (TextView) findViewById(R.id.tv_music_name);
        tvMusicAuthor = (TextView) findViewById(R.id.tv_music_author);
        tvMusicDuration = (TextView) findViewById(R.id.tv_music_duration);
        mSeekBarCurrent = (SeekBar) findViewById(R.id.seek_bar_current);
        setBottomMusicInfo();
    }

    @Override
    protected void initData() {
        setListener();
    }

    private void setBottomMusicInfo() {
        if (AppCache.getPlayingMusic() == null)return;
        tvMusicName.setText(AppCache.getPlayingMusic().getTitle());
        tvMusicAuthor.setText(AppCache.getPlayingMusic().getArtist());
        String imgPath = AppCache.getPlayingMusic().getAlbumArt();
        Glide.with(this).load(imgPath).placeholder(R.mipmap.default_music).into(img_bottom);
    }

    private void setListener() {
        viewPager.setOnPageChangeListener(this);
        tvLocal.setOnClickListener(this);
        tvOnline.setOnClickListener(this);
        tvHome.setOnClickListener(this);
        img_play.setOnClickListener(this);
        img_next.setOnClickListener(this);
        img_bottom.setOnClickListener(this);
        mSeekBarCurrent.setOnSeekBarChangeListener(this);
        navigationView.setNavigationItemSelectedListener(this);
    }



    @Override
    public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

    }

    @Override
    public void onPageSelected(int position) {
        changeTitleColor(position);
    }

    @Override
    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
        seekBarProgress = progress * (int) AppCache.getPlayingMusic().getDuration() / 100;
    }

    @Override
    public void onStartTrackingTouch(SeekBar seekBar) {

    }

    @Override
    public void onStopTrackingTouch(SeekBar seekBar) {
        //sendPlayInfo(AppConstant.ACTION_PLAY_STOP,true);
        getPlayService().seekBarPlay(seekBarProgress);
    }

    @Override
    public void onPageScrollStateChanged(int state) {

    }

    private void changeTitleColor(int position) {
        switch (position){
            case 0:
                tvLocal.setTextColor(getResources().getColor(R.color.gray_e));
                tvOnline.setTextColor(getResources().getColor(R.color.gray_e));
                tvHome.setTextColor(getResources().getColor(R.color.white));
                if (homeFragment != null)
                homeFragment.refreshMusicList();
                break;
            case 1:
                tvLocal.setTextColor(getResources().getColor(R.color.white));
                tvOnline.setTextColor(getResources().getColor(R.color.gray_e));
                tvHome.setTextColor(getResources().getColor(R.color.gray_e));
                if (localFragment != null)
                localFragment.refreshMusicList();
                break;
            case 2:
                tvLocal.setTextColor(getResources().getColor(R.color.gray_e));
                tvOnline.setTextColor(getResources().getColor(R.color.white));
                tvHome.setTextColor(getResources().getColor(R.color.gray_e));
                break;
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.img_next:
                //sendPlayInfo(AppConstant.ACTION__NEXT, false);
                getPlayService().onPlayNext();
                break;
            case R.id.img_play:
                //sendPlayInfo(AppConstant.ACTION_PLAY_STOP,false);
                getPlayService().playOrStop();

                break;
            case R.id.img_music_bottom:
                showPlayFragment();
                break;
            case R.id.tv_local:
                viewPager.setCurrentItem(1);
                changeTitleColor(1);
                break;
            case R.id.tv_online:
                viewPager.setCurrentItem(2);
                changeTitleColor(2);
                break;
            case R.id.tv_home:
                viewPager.setCurrentItem(0);
                changeTitleColor(0);
                break;
            case R.id.img_btn_category:
                drawer.openDrawer(GravityCompat.START);
                break;
            case R.id.img_btn_search:
                Intent intent = new Intent(this,SearchActivity.class);
                startActivity(intent);
                break;
            default:
                break;
        }
    }

    private void showPlayFragment() {
        if (isShowingFragment){
            return;
        }
        FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
        ft.setCustomAnimations(R.anim.fragment_slide_up, 0);
        if (playFragment == null){
            playFragment = new PlayFragment();
            ft.replace(android.R.id.content,playFragment);
        }else {
            ft.show(playFragment);
        }
        //ft.commitAllowingStateLoss();
        ft.commitNow();
        isShowingFragment = true;
        isShowedFragment = true;


        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                playFragment.updateInfo();
            }
        },1000);
    }

    boolean isShowingFragment = false;
    boolean isShowedFragment = false;//是否展示过

    public void hidePlayingFragment() {
        FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
        ft.setCustomAnimations(0, R.anim.fragment_slide_down);
        ft.hide(playFragment);
        ft.commitAllowingStateLoss();
        isShowingFragment = false;
    }

    /*
    * 启动服务播放音乐
    * */
    private void sendPlayInfo(String action,boolean usingSeekBar){
        if (AppCache.getLocalMusicList() != null ){
            Intent intent = new Intent();
            intent.setAction(action);
            if (usingSeekBar){
                intent.putExtra(AppConstant.MSG_PROGRESS, play_progress);
            }
            intent.setClass(MainActivity.this, PlayerService.class);
            startService(intent);
        }
    }

    @Override
    public void onMusicCurrentPosition(int currentPosition) {
        play_progress = currentPosition;
        int progress = play_progress * 100 / (int) AppCache.getPlayingMusic().getDuration();
        mSeekBarCurrent.setProgress(progress);
        tvMusicDuration.setText("" + Util.formatTime(play_progress));
        if (playFragment != null && isShowingFragment){
            playFragment.updateProgress(currentPosition);
        }

    }

    @Override
    public void onMusicStop() {
        img_play.setImageResource(R.mipmap.default_stop);

        if (isShowingFragment){
            playFragment.onMusicStop();
        }
    }

    @Override
    public void onMusicPlay() {
        setBottomMusicInfo();
        img_play.setImageResource(R.mipmap.default_playing);
        if (isShowingFragment){
            playFragment.onMusicPlay();
        }
    }

    @Override
    public void onMusicComplete() {
        img_play.setImageResource(R.mipmap.default_stop);
    }

    //view
    @Override
    public void onBackPressed() {

        if (isShowingFragment) {
            hidePlayingFragment();
            return;
        }

        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
            return;
        }
        super.onBackPressed();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main2, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_camera) {
            // Handle the camera action
        } else if (id == R.id.nav_gallery) {

        } else if (id == R.id.nav_slideshow) {

        } else if (id == R.id.nav_manage) {

        } else if (id == R.id.nav_share) {

        } else if (id == R.id.nav_send) {

        }
        //DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        //drawer.closeDrawer(GravityCompat.START);
        return true;
    }

}
