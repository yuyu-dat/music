package com.lei.musicplayer.bean;

/**
 * Created by lei on 2017/10/21.
 */
public class Lrc {
    private String lrcContent;

    public String getLrcContent() {
        return lrcContent;
    }

    public void setLrcContent(String lrcContent) {
        this.lrcContent = lrcContent;
    }

}
