package com.lei.musicplayer.constant;

/**
 * Created by lei on 2017/9/11.
 */
public interface Extra {

    String SONG_LIST_INFO = "SONG_LIST_INFO";

}
